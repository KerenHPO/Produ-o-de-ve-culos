public class Main {
    public static void main(String[] args) {
        int escolhaVeiculo = Teclado.lerInteiro("Escolha o tipo de veículo: 1. Carro  2. Moto  3. Caminhão");
        VeiculoFactory fabrica = null;

        switch (escolhaVeiculo) {
            case 1:
                fabrica = new FabricaCarros();
                break;
            case 2:
                fabrica = new FabricaMotos();
                break;
            case 3:
                fabrica = new FabricaCaminhoes();
                break;
            default:
                System.out.println("Opção inválida.");
                System.exit(1);
        }

        Motor motor = fabrica.criarMotor();
        Carroceria carroceria = fabrica.criarCarroceria();
        Rodas rodas = fabrica.criarRodas();
        Assentos assentos = fabrica.criarAssentos();
        SistemaEletrico sistemaEletrico = fabrica.criarSistemaEletrico();

        System.out.println("\n--- Especificações do Veículo ---");
        motor.especificacao();
        if (carroceria != null) carroceria.especificacao();
        if (rodas != null) rodas.especificacao();
        if (assentos != null) assentos.especificacao();
        if (sistemaEletrico != null) sistemaEletrico.especificacao();
    }
}
