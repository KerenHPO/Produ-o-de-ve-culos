
public class SistemaEletricoAvancado implements SistemaEletrico {
    @Override
    public void especificacao() {
        System.out.println("Sistema elétrico avançado.");
    }
}