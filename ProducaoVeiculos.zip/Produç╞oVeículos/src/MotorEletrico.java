
public class MotorEletrico implements Motor {
	    @Override
	    public void especificacao() {
	        System.out.println("Motor elétrico.");
	    }
}