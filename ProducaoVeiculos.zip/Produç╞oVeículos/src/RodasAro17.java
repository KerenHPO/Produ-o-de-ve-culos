
public class RodasAro17 implements Rodas {
    @Override
    public void especificacao() {
        System.out.println("Rodas aro 17.");
    }
}