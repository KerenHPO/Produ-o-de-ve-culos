
public class SistemaEletricoBasico implements SistemaEletrico {
    @Override
    public void especificacao() {
        System.out.println("Sistema elétrico básico.");
    }
}