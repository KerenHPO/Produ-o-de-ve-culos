
public interface Assentos {
	void especificacao();
}
