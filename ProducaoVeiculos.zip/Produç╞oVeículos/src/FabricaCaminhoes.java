// FabricaCaminhoes.java
public class FabricaCaminhoes implements VeiculoFactory {
    @Override
    public Motor criarMotor() {
        int escolha = Teclado.lerInteiro("Escolha o tipo de motor para o caminhão: 1. Elétrico  2. Combustão");
        if (escolha == 1) {
            return new MotorEletrico();
        } else {
            return new MotorCombustao();
        }
    }

    @Override
    public Carroceria criarCarroceria() {
        // Vamos assumir que todos os caminhões têm uma carroceria específica
        return new CarroceriaSUV(); 
    }

    @Override
    public Rodas criarRodas() {
        int escolha = Teclado.lerInteiro("Escolha o tamanho das rodas para o caminhão: 1. Aro 17  2. Aro 20");
        if (escolha == 1) {
            return new RodasAro17();
        } else {
            return new RodasAro20();
        }
    }

    @Override
    public Assentos criarAssentos() {
        // Assumindo assentos de tecido para caminhões
        return new AssentosTecido(); 
    }

    @Override
    public SistemaEletrico criarSistemaEletrico() {
        // Assumindo um sistema elétrico avançado para caminhões
        return new SistemaEletricoAvancado(); 
    }
}
