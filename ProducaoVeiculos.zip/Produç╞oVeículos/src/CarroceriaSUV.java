
public class CarroceriaSUV implements Carroceria {
    @Override
    public void especificacao() {
        System.out.println("Carroceria SUV.");
    }
}