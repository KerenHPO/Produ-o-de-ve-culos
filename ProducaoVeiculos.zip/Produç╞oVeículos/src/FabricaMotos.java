
public class FabricaMotos implements VeiculoFactory {
    @Override
    public Motor criarMotor() {
        int escolha = Teclado.lerInteiro("Escolha o tipo de motor para a moto: 1. Elétrico  2. Combustão");
        if (escolha == 1) {
            return new MotorEletrico();
        } else {
            return new MotorCombustao();
        }
    }

    @Override
    public Carroceria criarCarroceria() {
        // Motos geralmente não têm carroceria como um carro, pode ser opcional ou um tipo específico de carenagem.
        // Vamos optar por uma configuração padrão para este exemplo.
        System.out.println("Motos geralmente não têm carroceria como um carro. Configuração padrão de carenagem.");
        return new CarroceriaSedan(); 
    }

    @Override
    public Rodas criarRodas() {
        int escolha = Teclado.lerInteiro("Escolha o tamanho das rodas para a moto: 1. Aro 17  2. Aro 20");
        if (escolha == 1) {
            return new RodasAro17();
        } else {
            return new RodasAro20();
        }
    }

    @Override
    public Assentos criarAssentos() {
        int escolha = Teclado.lerInteiro("Escolha o tipo de assento para a moto: 1. Couro  2. Tecido");
        if (escolha == 1) {
            return new AssentosCouro();
        } else {
            return new AssentosTecido();
        }
    }

    @Override
    public SistemaEletrico criarSistemaEletrico() {
        int escolha = Teclado.lerInteiro("Escolha o sistema elétrico para a moto: 1. Básico  2. Avançado");
        if (escolha == 1) {
            return new SistemaEletricoBasico();
        } else {
            return new SistemaEletricoAvancado();
        }
    }
}
