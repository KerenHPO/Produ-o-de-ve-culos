
public class RodasAro20 implements Rodas {
    @Override
    public void especificacao() {
        System.out.println("Rodas aro 20.");
    }
}