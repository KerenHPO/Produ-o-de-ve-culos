
public interface Carroceria {
	void especificacao();
}
