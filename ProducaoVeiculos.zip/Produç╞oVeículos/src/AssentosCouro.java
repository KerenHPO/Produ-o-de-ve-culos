
public class AssentosCouro implements Assentos {
    @Override
    public void especificacao() {
        System.out.println("Assentos de couro.");
    }
}