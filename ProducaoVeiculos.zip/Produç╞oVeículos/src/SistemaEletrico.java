
public interface SistemaEletrico {
	void especificacao();
}
