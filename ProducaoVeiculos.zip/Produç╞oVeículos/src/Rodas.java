
public interface Rodas {
	void especificacao();
}
