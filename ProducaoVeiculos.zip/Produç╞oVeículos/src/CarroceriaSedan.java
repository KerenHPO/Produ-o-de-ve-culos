
public class CarroceriaSedan implements Carroceria {
    @Override
    public void especificacao() {
        System.out.println("Carroceria Sedan.");
    }
}