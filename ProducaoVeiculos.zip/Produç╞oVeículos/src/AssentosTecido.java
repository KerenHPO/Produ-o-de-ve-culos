
public class AssentosTecido implements Assentos {
    @Override
    public void especificacao() {
        System.out.println("Assentos de tecido.");
    }
}