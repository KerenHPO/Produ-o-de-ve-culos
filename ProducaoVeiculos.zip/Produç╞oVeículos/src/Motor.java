
public interface Motor {
	void especificacao();
}
