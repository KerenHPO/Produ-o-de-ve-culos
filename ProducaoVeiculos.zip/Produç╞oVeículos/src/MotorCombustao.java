
public class MotorCombustao implements Motor {
    @Override
    public void especificacao() {
        System.out.println("Motor a combustão.");
    }
}